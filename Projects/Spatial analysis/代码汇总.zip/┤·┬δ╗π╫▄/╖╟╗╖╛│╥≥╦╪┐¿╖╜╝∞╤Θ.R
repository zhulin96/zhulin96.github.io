#卡方检验
#判断非环境因素对疾病的影响
setwd("F:/卓工班项目/代码测试(new)")
data1<-read.csv("2010_parents.csv")
data2<-read.csv("2011_parents.csv")
data3<-read.csv("2012_parents.csv")
data4<-read.csv("2013_parents.csv")
data5<-read.csv("2014_parents.csv")
data6<-read.csv("2015_parents.csv")
#提取分析数据
data1<-data1[,c("fage","mage","mjob","fjob","mnationality","fnationalty","medu_level","fedu_level","maccount_type","intermarry","is_ill_A","anemia_A","dysgnosia",
               "favism","hearing_disorder","congenital_heart_disease","seeing_disorder","infant_mortality","disease_history_f_others","dysgnosia_A","favism_A",
              "hearing_disorder_A","congenital_heart_disease_A","seeing_disorder_A","infant_mortality_A","disease_history_f_others_A","is_ill_baby")]
data2<-data2[,c("fage","mage","mjob","fjob","mnationality","fnationalty","medu_level","fedu_level","maccount_type","intermarry","is_ill_A","anemia_A","dysgnosia",
                "favism","hearing_disorder","congenital_heart_disease","seeing_disorder","infant_mortality","disease_history_f_others","dysgnosia_A","favism_A",
                "hearing_disorder_A","congenital_heart_disease_A","seeing_disorder_A","infant_mortality_A","disease_history_f_others_A","is_ill_baby")]
data3<-data3[,c("fage","mage","mjob","fjob","mnationality","fnationalty","medu_level","fedu_level","maccount_type","intermarry","is_ill_A","anemia_A","dysgnosia",
                "favism","hearing_disorder","congenital_heart_disease","seeing_disorder","infant_mortality","disease_history_f_others","dysgnosia_A","favism_A",
                "hearing_disorder_A","congenital_heart_disease_A","seeing_disorder_A","infant_mortality_A","disease_history_f_others_A","is_ill_baby")]
data4<-data4[,c("fage","mage","mjob","fjob","mnationality","fnationalty","medu_level","fedu_level","maccount_type","intermarry","is_ill_A","anemia_A","dysgnosia",
                "favism","hearing_disorder","congenital_heart_disease","seeing_disorder","infant_mortality","disease_history_f_others","dysgnosia_A","favism_A",
                "hearing_disorder_A","congenital_heart_disease_A","seeing_disorder_A","infant_mortality_A","disease_history_f_others_A","is_ill_baby")]
data5<-data5[,c("fage","mage","mjob","fjob","mnationality","fnationalty","medu_level","fedu_level","maccount_type","intermarry","is_ill_A","anemia_A","dysgnosia",
                "favism","hearing_disorder","congenital_heart_disease","seeing_disorder","infant_mortality","disease_history_f_others","dysgnosia_A","favism_A",
                "hearing_disorder_A","congenital_heart_disease_A","seeing_disorder_A","infant_mortality_A","disease_history_f_others_A","is_ill_baby")]
data6<-data6[,c("fage","mage","mjob","fjob","mnationality","fnationalty","medu_level","fedu_level","maccount_type","intermarry","is_ill_A","anemia_A","dysgnosia",
                "favism","hearing_disorder","congenital_heart_disease","seeing_disorder","infant_mortality","disease_history_f_others","dysgnosia_A","favism_A",
                "hearing_disorder_A","congenital_heart_disease_A","seeing_disorder_A","infant_mortality_A","disease_history_f_others_A","is_ill_baby")]
data<-rbind(data1,data2,data3,data4,data5,data6)
data[is.na(data)]<-0
#判断遗传因素
for (i in c(1:length(data$is_ill_baby))) {
  if ( 1 %in% c(data$dysgnosia[i],data$favism[i],data$hearing_disorder[i],data$congenital_heart_disease[i],data$seeing_disorder[i],data$infant_mortality[i],data$disease_history_f_others[i],
                data$dysgnosia_A[i],data$favism_A[i],data$hearing_disorder_A[i],data$congenital_heart_disease_A[i],data$seeing_disorder_A[i],data$infant_mortality_A[i],data$disease_history_f_others_A[i]))
  {
    data$herit_ill[i]<-1
  }
  else{
    data$herit_ill[i]<-0
  }
}
#对年龄数据需要按照35岁界限进行划分分类
#对职业、教育程度、民族、现居地删除未记录在内的数据
#age
age<-c()
is_ill_baby<-c()
for (i in c(1:length(data$is_ill_baby))){
  if (data$fage[i] >0 & data$fage[i]<=35){
    age<-c(age,0)
    is_ill_baby<-c(is_ill_baby, data$is_ill_baby[i])
  }
  if(data$fage[i]>35){
    age<-c(age, 1)
    is_ill_baby<-c(is_ill_baby, data$is_ill_baby[i])
  }
}

#以edu_level为例
edu_level<-c()
is_ill_baby<-c()
for (i in c(1:length(data$is_ill_baby))){
  if (data$medu_level[i] >0){
    account_type<-c(account_type,data$medu_level[i])
    is_ill_baby<-c(is_ill_baby, data$is_ill_baby[i])
  }
}


#卡方检验,以年龄判断为例
data_statistic<-data.frame(age=age,is_ill=is_ill_baby)
data1=table(data_statistic$age,data_statistic$is_ill)
chisq.test(data1)




