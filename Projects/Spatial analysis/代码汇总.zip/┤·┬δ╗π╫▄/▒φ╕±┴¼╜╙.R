#生成相互匹配的父母体检数据、孕早期数据和胎儿数据
library(foreign)
setwd("F:/卓工班项目/代码测试(new)")

#读取文件
data_parents1<-read.spss("raw data/2015.sav",fileEncoding="GBK")
data_parents1$service_code<-gsub(" ","",data_parents1$service_code)
data_baby1<-read.spss("raw data/2015_baby.sav", fileEncoding="GBK")
data_baby1$service_code<-gsub(" ","",data_baby1$service_code)
data_pregnancy1<-read.spss("raw data/早孕/2015.sav",header=TRUE,fileEncoding="GBK")
data_pregnancy1$service_code<-gsub(" ","",data_pregnancy1$service_code)
data_pregnancy1$service_code[1]
n<-0

#修改is_ill数据，添加死亡病例数据
for (i in c(1: length(data_baby1$service_code))){
  if (data_baby1$baby_live[i] %in% c(0,2,3,4)){
    data_baby1$is_ill[i]<-1
    n<-n+1
    print(n)
  }
}

#三个表格按照统一的档案编号进行匹配
#提取servce_code数据，删除重复出现数据，并将数据转换为datafrmae格式
test1<-data_parents1$service_code
test2<-data_pregnancy1$service_code
test3<-data_baby1$service_code
test1<-test1[!duplicated(test1)]
test2<-test2[!duplicated(test2)]
test3<-test3[!duplicated(test3)]
data_baby1<-data.frame(data_baby1)
data_parents1<-data.frame(data_parents1)
data_pregnancy1<-data.frame(data_pregnancy1)
data_baby1<-data_baby1[!duplicated(data_baby1$service_code),]
data_parents1<-data_parents1[!duplicated(data_parents1$service_code),]
data_pregnancy1<-data_pregnancy1[!duplicated(data_pregnancy1$service_code),]

#baby数据与怀孕早期调查数据进行匹配
code<-c()
code1<-c()
add<-c()
n<-0

for (i in c(1:length(test3))){
  for(j in c(1:length(test2))){
    if (test3[i]==test2[j])
    {
      code<-c(code,test3[i])
      code1<-c(code1,j)
      add<-c(add,i)
    }
  }
}

#怀孕早期数据与父母体检数据进行匹配
n<-0
code2<-c()
code3<-c()
code[1]
code1[1]
length(code)
for (i in c(1:length(code))){
  for(j in c(1:length(test1))){
    
    if (code[i]==test1[j])
    {
      code2<-c(code2,j)
      code3<-c(code3,test1[j])
      n<-n+1
      print(n)
    }
  }
}

#按照匹配后的行数编号提取数据
result=data_baby1[add,]            #胎儿数据
result1=data_pregnancy1[code1,]    #怀孕早期调查数据
result2=data_parents1[code2,]      #父母体检数据

write.csv(result,file="2015_baby.csv",fileEncoding = "GBK")
write.csv(result1,file="2015_pregnancy.csv",fileEncoding = "GBK")
write.csv(result2,file="2015_parents.csv",fileEncoding = "GBK")

