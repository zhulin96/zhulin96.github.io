setwd("F:/卓工班项目/birth_defect")
library(sp)
library(maptools)
library(maps)
library(robustbase)
library(Rcpp)
library(GWmodel)
library(ggplot2)
library(RColorBrewer)
library(scales)
library(plyr)
#导入shp数据
yunnan_map<-readShapePoly("yunnan/yunnan.shp")
#构建点数据矩阵
yunnan_map$LON[1]
data1<-matrix(yunnan_map$LON,nrow = 129)
data2<-matrix(yunnan_map$LAT,nrow = 129)
data<-as.matrix(cbind(data1,data2))
#计算距离
dist<-gw.dist(dp.locat = data)
#确定带宽
bw<-bw.gwr(P~DEM+buffer+marrige+GDP,data= yunnan_map,approach = "CV",kernel = "gaussian",adaptive = FALSE, p=2, theta =0, longlat = F, dist)
#montecarlo检验
res.mont1<-gwr.montecarlo(P~DEM+buffer+marrige+GDP, data = yunnan_map,dMat=dist,
                          nsim=99, kernel="gaussian", adaptive=FALSE, bw=0.75)
#回归模型的选择
DeVar<-"P"
InDeVars<-c("DEM","buffer","marrige", "GDP")
res.model1<-gwr.model.selection(DeVar , InDeVars,data=yunnan_map, bw=bw,dMat=dist,kernel = "gaussian")
model.list<-res.model1[[1]]
gwr.model.view("share", c("DEM","buffer","marrige", "GDP"),model.list)
#进行地理加权回归建模
gwr.res1<-gwr.basic(P~DEM+buffer+marrige+GDP,data = yunnan_map,bw=bw,kernel="gaussian",dMat = dist)

#绘制结果图
yunnan_map1<-fortify(yunnan_map)
x <- yunnan_map@data
xs <- data.frame(id=row.names(x),x)
mydata <-data.frame(id=xs$id,Local_R2=gwr.res1$SDF$Stud_residual)
yunnan_data<-join(xs,mydata,type="full")
yunnan_data <- join(yunnan_map1, yunnan_data, type ="full")
yunnan_data$R2_q<-cut(yunnan_data$R2_q,c(0,0.2,0.4,0.6,0.8,1),labels= c("0-0.2","0.2-0.4","0.4-0.6","0.6-0.8","0.8-1"),include.lowest = TRUE)
ggplot(yunnan_data,aes(long,lat))+
  geom_polygon(aes(group=group,fill=R2_q),colour="black",size=0.25)+
  scale_fill_brewer(palette="RdYlGn")+
  coord_map("polyconic") 

