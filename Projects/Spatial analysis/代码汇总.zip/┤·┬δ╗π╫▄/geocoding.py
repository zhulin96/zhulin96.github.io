# -*- coding: utf-8 -*-
import csv
import codecs
import urllib
import math
import re
import requests
import sys
import time


##filename=['2010.csv','2011.csv','2012.csv','2013.csv','2014.csv']
##filelength=[403,402,405,410,410]    #数据列数
##addr_startindex=[[29,30,31,32],[29,30,31,32],[29,30,31,32],[29,30,31,32],[28,29,30,31]]    #各级地址所在列（0开始计数）
filename=['test.csv']
filelength=[19]    #数据列数
addr_startindex=[[26,27,28],[30,31,32],[36,37,38]]    #各级地址所在列（0开始计数）

#墨卡托转wgs84
def mercator2wgs84(mercator):
    point_x=mercator[0]
    point_y=mercator[1]
    x=point_x/20037508.3427892*180
    y=point_y/20037508.3427892*180
    y=180/math.pi*(2*math.atan(math.exp(y*math.pi/180))-math.pi/2)
    return (x,y)

#获取墨卡托坐标 
def get_mercator(addr):
    quote_addr=urllib.quote(addr)
##    province=urllib.quote(u'云南省'.encode('utf8'))
##    if quote_addr.startswith(province):
##        pass
##    else:
##        quote_addr=province+quote_addr
    s=urllib.quote(u'北京市'.encode('utf8'))
    api_addr="http://api.map.baidu.com/?qt=gc&wd=%s&cn=%s&ie=utf-8&oue=1&fromproduct=jsapi&res=api&callback=BMap._rd._cbk62300"%(quote_addr,s)
    try:
        req=requests.get(api_addr)
    except:
        try:
            time.sleep(0.01)
            req=requests.get(api_addr)
        except:
            try:
                time.sleep(0.01)
                req=requests.get(api_addr)
            except:
                return (0.0,0.0)
    content=req.content
    x=re.findall(pattern_x,content)
    y=re.findall(pattern_y,content)
    if x:
        x=x[0]
        y=y[0] 
        x=x[1:-1]
        y=y[1:-1]
        x=float(x)
        y=float(y)
        location=(x,y)
    else:
        location=()
    time.sleep(1)    
    return location

for number in range(len(filename)):
    #合并三级地址存储至addr中----------------------------------------------------------------------------------------------------------------------------------
    a=open(filename[number],'rb')
    a.readline()
    r=1  #用来记录行数
    addr=[]   #不含表头
    a1=csv.reader(a,delimiter=',')
    #for n in range(0,3):
    for row in a1:
        s=''
        for t in range(len(addr_startindex[0])):
            s=s+row[addr_startindex[0][t]]
        addr.append(s)
        s=''
        for t in range(len(addr_startindex[1])):
            s=s+row[addr_startindex[1][t]]
        addr.append(s)
        s=''
        for t in range(len(addr_startindex[2])):
            s=s+row[addr_startindex[2][t]]
        addr.append(s)
        r=r+1
    a.close()
   

    #解算addr对应经纬度---------------------------------------------------------------------------------------------------------------------------------------
    pattern_x=re.compile(r'"x":(".+?")')
    pattern_y=re.compile(r'"y":(".+?")')

    #获取经纬度
    lat=[]
    lon=[]
    addr_used=[]
    for i in range(len(addr)):
        if i==0:
            mercator=get_mercator(addr[i])
            if mercator:
                wgs=mercator2wgs84(mercator)
            else:
                wgs=('NotFound','NotFound')
            print i,addr[i].decode('utf8').encode('gbk'), wgs[0], wgs[1]
            lat.append(wgs[0])
            lon.append(wgs[1])            
        else:
            if addr[i] in addr_used and addr[i] != '':
                for j in range(i):
                    if addr[i]==addr[j]:
                        wgs=(lat[j],lon[j])
                        break
            else:
                mercator=get_mercator(addr[i])
                if mercator:
                    wgs=mercator2wgs84(mercator)
                else:
                    wgs=('NotFound','NotFound')
            print i,addr[i].decode('utf8').encode('gbk'), wgs[0], wgs[1]
            lat.append(wgs[0])
            lon.append(wgs[1])
        addr_used.append(addr[i])


    #重写数据表-------------------------------------------------------------------------------------------------------
    b=open(filename[number],'rb')
    b1=csv.reader(b,delimiter=',')
    name=['Lat','Lon','FLat','FLon','MLat','MLon']
    #创建并初始化data
    #data=[['']*(filelength[number]+2)]*r
    data=[[' ' for x in range(filelength[number]+6)] for y in range(r)]
    #填充数据
    #r_temp=0
    #temp=0
	
    #为表格已知属性列赋值
    #for row in b1:
    #    for i_2 in range(filelength[number]):
    #        type = sys.getfilesystemencoding()  #解决utf-8编码中文乱码问题
    #        data[temp][i_2+6]=row[i_2].decode('UTF-8').encode(type)
    #    r=temp+1
	
    #为坐标属性列赋值
    #for n in range(0,3):
    #    for row in b1:
    #        if r_temp>0:
    #            data[r_temp][2*n]=lat[r_temp-1]
    #            data[r_temp][2*n+1]=lon[r_temp-1]
    #        else:
    #            data[r_temp][2*n]=name[2*n]
    #            data[r_temp][2*n+1]=name[2*n+1]
    #        r_temp=r_temp+1
    #    r_temp=0
    #b.close()
    r_temp=0
    for row in b1:
        for i_2 in range(filelength[number]):
            type = sys.getfilesystemencoding()  #解决utf-8编码中文乱码问题
            data[r_temp][i_2+6]=row[i_2].decode('UTF-8').encode(type)
        if r_temp>0:
            data[r_temp][0]=lat[(r_temp-1)*3]
            data[r_temp][1]=lon[(r_temp-1)*3]
            data[r_temp][2]=lat[(r_temp-1)*3+1]
            data[r_temp][3]=lon[(r_temp-1)*3+1]
            data[r_temp][4]=lat[(r_temp-1)*3+2]
            data[r_temp][5]=lon[(r_temp-1)*3+2]
        else:
            data[r_temp][0]='Lat'
            data[r_temp][1]='Lon'
            data[r_temp][2]='FLat'
            data[r_temp][3]='FLon'
            data[r_temp][4]='MLat'
            data[r_temp][5]='MLon'   
        r_temp=r_temp+1
    b.close()
    #写新表
    with open("(new)"+filename[number],'wb') as outfile:
        writer1 = csv.writer(outfile,dialect='excel')
        writer1.writerows(data)

    print filename[number]+" finshed"

    
        
    




