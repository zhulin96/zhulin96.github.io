library("sp")  
library("maptools") 
library("spdep")  

path <- "F:\\卓工班项目\\birth_defect\\yunnan\\"

#将中国的省级行政区划读取为ploygon  
sids<- readShapePoly(paste(path,"yunnan.shp",sep =""))  
#定义投影为wgs84  
proj4string(sids) <- "+proj=longlat +datum=WGS84"  
#定义唯一标识符，用省级行政区划的编码  
IDs <- sids$id 
#将名称转换为gbk编码  
sids$name <- iconv(sids$name,"UTF-8","GBK")  
coords<-coordinates(sids)
#Queen matrix
sids_nbq<-poly2nb(sids)
plot(sids)
plot(sids_nbq,coords,add=T)
sids_nbq_wb<-nb2listw(sids_nbq, style = "B",zero.policy = T)
moran.test(sids$P, listw = sids_nbq_wb,zero.policy = T)
#基于距离的权重矩阵
#获得最长的邻接距离
sids_kn1<-knn2nb(knearneigh(coords,k=1),row.names=IDs)
dist<-unlist(nbdists(sids_kn1,coords))
summary(dist)
max_k1<-max(dist)
sids_kd<-dnearneigh(coords,d1=0,d2=max_k1, row.names=IDs)
sids_kd_wb<-nb2listw(sids_kd,style = "B",zero.policy = T)
moran.test(sids$P,listw=sids_kd_wb,zero.policy = T)

moran.plot(sids$share, listw = sids_nbq_wb)
