import csv
import pandas as pd

filename=['(new)test.csv']
filelength=[19]

a=open(filename[0],'rb')
a1=csv.reader(a,delimiter=',')
rows=[]
s=''
for row in a1:
    if row[0]=='Lat':
        rows.append(row)
    elif row[0]!='NotFound':
        rows.append(row)
    else:
        if row[4]=='NotFound':
            continue
        elif row[4]!='NotFound':
            row[0]=row[4]
            row[1]=row[5]
            rows.append(row)
a.close()

csvfile=file(filename[0],'wb')
writer=csv.writer(csvfile)
writer.writerows(rows)
csvfile.close()


            
            
            
