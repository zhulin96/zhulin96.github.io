#各地区通婚率计算
#利用丈夫和妻子的身份证号的前6位的区位号来判断丈夫与妻子的出生所属地
library(foreign)
library(rgeos)
library(maptools)
library(ggplot2)
library(plyr)
library(Cairo) #图片高清导出
library(RColorBrewer)#存储了配色方案
library(scales)#用于数据分割
library(stringr)#用于字符串解析
setwd("F:/卓工班项目/代码测试(new)")
yunnan_map<-readShapePoly("yunnan/yunnan.shp")
yunnan_map1<-fortify(yunnan_map)
data<-read.spss("raw data/2015.sav")

#创建结果表格 
ID<-yunnan_map$id
county<-yunnan_map$name
total_noun<-1:length(yunnan_map$id)
share<-1:length(yunnan_map$id)
#通婚情况
marriage<-1:length(yunnan_map$id)
marriage[]<-0

total_noun[]<-0
share[]<-0
result<-data.frame(ID,county,total_noun,marriage,share)
data<-data.frame(data)
#factor转character
data$mid_card<-as.character(data$mid_card)
data$fid_card<-as.character(data$fid_card)
data$mid_card[502]
#删除身份证号不存在数据
data<-data[which(data$mid_card!= "                  "),]
data<-data[which(data$fid_card!= "                  "),]
length(data$fid_card)

delete<-c(0)
data$address_county<-as.character(data$address_county)
data$maccount_location_county<-as.character(data$maccount_location_county)
#进行县级地址匹配
for (i in c(1: length(data$service_code))) {
  #家庭住址存在
  if (data$address_county[i]!="      "){
    id<-pmatch(str_sub(data$address_county[i],1,2),yunnan_map$name,nomatch = 0)
    #统计未匹配成功的数目
    if(id==0){
      delete<-c(delete,i)
    }
    #各地区家庭数目统计
    result$total_noun[id]=result$total_noun[id]+1
    #身份证号匹配
    fid<-str_sub(data$fid_card[i],1,6)
    mid<-str_sub(data$mid_card[i],1,6)
    if (match(fid,mid,nomatch = 0)){
      result$marriage[id]=result$marriage[id]+1
    }
  }
  else{
    #家庭住址不存在利用丈夫户口地址代替
    id<-pmatch(str_sub(data$maccount_location_county[i],1,2),yunnan_map$name,nomatch = 0)
    if(id==0){
      delete<-c(delete,i)
    }
    result$total_noun[id]=result$total_noun[id]+1
    #身份证号匹配
    fid<-str_sub(data$fid_card[i],1,6)
    mid<-str_sub(data$mid_card[i],1,6)
    if (match(fid,mid,nomatch = 0)){
      result$marriage[id]=result$marriage[id]+1
    }
  }
}
length(delete)
View(result)
write.csv(result,file="marriage_2015.csv",fileEncoding = "GBK")

#读取历年的通婚数统计文件，计算出总的通婚率
result1<-read.csv("marriage_2010.csv")
result2<-read.csv("marriage_2011.csv")
result3<-read.csv("marriage_2012.csv")
result4<-read.csv("marriage_2013.csv")
result5<-read.csv("marriage_2014.csv")
result6<-read.csv("marriage_2015.csv")
for (i in c(1: length(result1$share))) {
  #result<-data.frame(ID,county,total_noun,radial,noise,lead_hg,new_decoration,high_temperature,pesticide,share)
  result1$total_noun[i]<-result1$total_noun[i]+result2$total_noun[i]+result3$total_noun[i]+result4$total_noun[i]+result5$total_noun[i]+result6$total_noun[i]
  result1$marriage[i]<-result1$marriage[i]+result2$marriage[i]+result3$marriage[i]+result4$marriage[i]+result5$marriage[i]+result6$marriage[i]
}
for (i in c(1: length(result1$share))){
  result1$share[i]<-result$marriage[i]/result1$total_noun[i]
}
write.csv(result1,file="marriage.csv",fileEncoding = "GBK")




