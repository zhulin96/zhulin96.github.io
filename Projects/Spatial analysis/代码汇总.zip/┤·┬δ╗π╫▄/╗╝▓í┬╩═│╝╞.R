#各地区患病率计算
#利用数据中的地址字段与区域名称进行字段匹配判断各个家庭所属地区
#来统计各个地区的患病人数和患病率
library(foreign)
library(rgeos)
library(maptools)
library(ggplot2)
library(plyr)
library(Cairo) #图片高清导出
library(RColorBrewer)#存储了配色方案
library(scales)#用于数据分割
library(stringr)#用于字符串解析


setwd("F:/卓工班项目/代码测试")
yunnan_map<-readShapePoly("yunnan/yunnan.shp")
yunnan_map1<-fortify(yunnan_map)
data_orig<-read.csv("2010.csv")

#创建结果表格，用于存储统计结果
ID<-yunnan_map$id
county<-yunnan_map$name
total_noun<-1:length(yunnan_map$id)
ill_noun<-1:length(yunnan_map$id)
share<-1:length(yunnan_map$id)
total_noun[]<-0
ill_noun[]<-0
share[]<-0
result<-data.frame(ID,county,total_noun,ill_noun,share)

#用于统计为成功参与匹配的数据
delete<-c(0)

#进行县级地址匹配
for (i in c(1: length(data_orig$Lat))) {
  #家庭住址存在
  if (data_orig$address_county[i]!=" "){
    id<-pmatch(str_sub(data_orig$address_county[i],1,2),yunnan_map$name,nomatch = 0)
  #统计未匹配成功的数目
    if(id==0){
      delete<-c(delete,i)
    }
  #各地区家庭数目统计
    result$total_noun[id]=result$total_noun[id]+1
  #各地区患病家庭数目统计
    if (pmatch(data_orig$anemia_A[i],c(1),nomatch = 0)|pmatch(data_orig$anemia[i],c(1),nomatch = 0)){
      result$ill_noun[id]=result$ill_noun[id]+1
    }
  }
  else{
  #家庭住址不存在利用丈夫户口地址代替
    id<-pmatch(str_sub(data_orig$maccount_location_county[i],1,2),yunnan_map$name,nomatch = 0)
    if(id==0){
      delete<-c(delete,i)
    }
    result$total_noun[id]=result$total_noun[id]+1
    if (pmatch(data_orig$anemia_A[i],c(1),nomatch = 0)|pmatch(data_orig$anemia[i],c(1),nomatch = 0)) {
      result$ill_noun[id]=result$ill_noun[id]+1
    }
  }
}
#计算患病率
for (i in c(1:length(result$ID))){
  if(result$total_noun[i]==0){
    result$share[i]<-0
  }
  else{
    result$share[i]<-round(result$ill_noun[i]/result$total_noun[i],4)
  }
} 

length(delete)
delete



#
#地图显示
#数据按照层级进行分割
result$share_q<-cut(result$share,breaks=c(0,0.006,0.012,0.018,0.024,0.03),labels= c("0-0.006","0.006-0.012","0.012-0.018","0.018-0.024","0.024-0.03"),include.lowest = TRUE)
x<-result$share_q
new<-data.frame(x,id=seq(1:129)-1)
yunnan_mapdata<-join(yunnan_map1,new,type="full")

ggplot(yunnan_mapdata,aes(long,lat))+
  geom_polygon(aes(group=group,fill=x),colour="grey65",size=0.25)+
  scale_fill_brewer(palette="Blues")+
  coord_map("polyconic") +
  guides(fill=guide_legend(reverse=TRUE,title=NULL))+
  theme(
    panel.grid = element_blank(),
    panel.background = element_blank(),
    axis.text = element_blank(),
    axis.ticks = element_blank(),
    axis.title = element_blank(),
    legend.position = c(0,0.7),
    legend.background = element_blank(),
    legend.text.align=1,
    legend.key.width=unit(1,"line"),
    legend.key.height=unit(1,"line")
    )


