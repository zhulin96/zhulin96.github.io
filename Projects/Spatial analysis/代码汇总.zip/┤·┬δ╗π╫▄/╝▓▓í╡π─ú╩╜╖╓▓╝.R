library(maptools)
library(aspace)
library(rgeos)
library(ggplot2)
library(ggmap)
library(remMap)
library(plyr)
setwd("F:/卓工班项目/birth_defect")
yunnan_map<-readShapePoly("yunnan/yunnan.shp")
river<-readShapeLines("river/hyd2_4.shp")
river1<-fortify(river)
yunnan_map1<-fortify(yunnan_map)
data1<-read.csv("(new)2010_baby(address).csv")
data2<-read.csv("(new)2011_baby(address).csv")
data3<-read.csv("(new)2012_baby(address).csv")
data4<-read.csv("(new)2013_baby(address).csv")
data5<-read.csv("(new)2014_baby(address).csv")
data6<-read.csv("(new)2015_baby(address).csv")

data1$Lon<-as.numeric(data1$Lon)
data1$Lat<-as.numeric(data1$Lat)
data2$Lon<-as.numeric(data2$Lon)
data2$Lat<-as.numeric(data2$Lat)
data3$Lon<-as.numeric(data3$Lon)
data3$Lat<-as.numeric(data3$Lat)
data4$Lon<-as.numeric(data4$Lon)
data4$Lat<-as.numeric(data4$Lat)
data5$Lon<-as.numeric(data5$Lon)
data5$Lat<-as.numeric(data5$Lat)
data6$Lon<-as.numeric(data6$Lon)
data6$Lat<-as.numeric(data6$Lat)

data1<-data1[which(data1$is_ill==1),c("Lat","Lon")]
data2<-data2[which(data2$is_ill==1),c("Lat","Lon")]
data3<-data3[which(data3$is_ill==1),c("Lat","Lon")]
data4<-data4[which(data4$is_ill==1),c("Lat","Lon")]
data5<-data5[which(data5$is_ill==1),c("Lat","Lon")]
data6<-data6[which(data6$is_ill==1),c("Lat","Lon")]

mp1<-mean_centre(id=1,filename = "output1.txt",weighted = FALSE,weights = NULL,points = data1)
mp2<-mean_centre(id=2,filename = "output2.txt",weighted = FALSE,weights = NULL,points = data2)
mp3<-mean_centre(id=3,filename = "output3.txt",weighted = FALSE,weights = NULL,points = data3)
mp4<-mean_centre(id=4,filename = "output4.txt",weighted = FALSE,weights = NULL,points = data4)
mp5<-mean_centre(id=5,filename = "output5.txt",weighted = FALSE,weights = NULL,points = data5)
mp6<-mean_centre(id=5,filename = "output6.txt",weighted = FALSE,weights = NULL,points = data5)

combine<-rbind(data1,data2,data3,data4,data5,data6)
sde1 = calc_sde(centre.xy=NULL,calccentre=TRUE,weighted=FALSE, weights=NULL, points=data1,verbose=FALSE)
sde2 = calc_sde(centre.xy=NULL,calccentre=TRUE,weighted=FALSE, weights=NULL, points=data2,verbose=FALSE)
sde3 = calc_sde(centre.xy=NULL,calccentre=TRUE,weighted=FALSE, weights=NULL, points=data3,verbose=FALSE)
sde4 = calc_sde(centre.xy=NULL,calccentre=TRUE,weighted=FALSE, weights=NULL, points=data4,verbose=FALSE)
sde5 = calc_sde(centre.xy=NULL,calccentre=TRUE,weighted=FALSE, weights=NULL, points=data5,verbose=FALSE)
sde6 = calc_sde(centre.xy=NULL,calccentre=TRUE,weighted=FALSE, weights=NULL, points=data6,verbose=FALSE)
sde = calc_sde(centre.xy=NULL,calccentre=TRUE,weighted=FALSE, weights=NULL, points=combine,verbose=FALSE)

#历年病例可视化
ggplot()+
  geom_polygon(data=yunnan_map1,aes(x=long,y=lat,group=group),fill="white",col="grey60",size=.1)+
  coord_map("polyconic") +
  geom_path(data=river1,aes(x=long,y=lat,group=group),col="blue",size=1.3)+
  geom_point(data=data1,aes(x =Lat,y =Lon),size=2,pch=21,fill="yellow")+
  geom_point(data=data2,aes(x =Lat,y =Lon),size=2,pch=21,fill="green")+
  geom_point(data=data3,aes(x =Lat,y =Lon),size=2,pch=21,fill="blue")+
  geom_point(data=data4,aes(x =Lat,y =Lon),size=2,pch=21,fill="orange")+
  geom_point(data=data5,aes(x =Lat,y =Lon),size=2,pch=21,fill="black")+
  geom_point(data=data6,aes(x =Lat,y =Lon),size=2,pch=21,fill="purple")

#历年患病中心可视化
ggplot()+
  geom_polygon(data=yunnan_map1,aes(x=long,y=lat,group=group),fill="white",col="grey60",size=.1)+
  coord_map("polyconic") +
  geom_path(data=river1,aes(x=long,y=lat,group=group),col="blue",size=1.3)+
  geom_point(data=data1,aes(x =Lat,y =Lon),size=2,pch=21,fill="black")+
  geom_point(data=data2,aes(x =Lat,y =Lon),size=2,pch=21,fill="blaCK")+
  geom_point(data=data3,aes(x =Lat,y =Lon),size=2,pch=21,fill="black")+
  geom_point(data=data4,aes(x =Lat,y =Lon),size=2,pch=21,fill="black")+
  geom_point(data=data5,aes(x =Lat,y =Lon),size=2,pch=21,fill="black")+
  geom_point(data=data6,aes(x =Lat,y =Lon),size=2,pch=21,fill="black")+
  geom_point(data=mp1,aes(x=mp1$CENTRE.x,y=mp1$CENTRE.y),cex=3,fill="red",pch=22)+
  geom_point(data=mp2,aes(x=mp2$CENTRE.x,y=mp2$CENTRE.y),cex=3,fill="red",pch=23)+
  geom_point(data=mp3,aes(x=mp3$CENTRE.x,y=mp3$CENTRE.y),cex=3,fill="red",pch=24)+
  geom_point(data=mp4,aes(x=mp4$CENTRE.x,y=mp4$CENTRE.y),cex=3,fill="red",pch=25)+
  geom_point(data=mp5,aes(x=mp5$CENTRE.x,y=mp5$CENTRE.y),cex=3,fill="red",pch=21)+
  geom_point(data=mp6,aes(x=mp6$CENTRE.x,y=mp6$CENTRE.y),cex=3,fill="red",pch=21)

#历年病例的标准差椭圆可视化
ggplot()+
  geom_polygon(data=yunnan_map1,aes(x=long,y=lat,group=group),fill="white",col="grey60",size=.1)+
  coord_map("polyconic") +
  geom_polygon(data=sde,aes(x=sde$x,y=sde$y,group=1),fill="grey90",col="grey90",size=0.5)+
  geom_path(data=river1,aes(x=long,y=lat,group=group),col="blue",size=1.3)+
  geom_point(data=data1,aes(x =Lat,y =Lon),size=2,pch=21,fill="black")+
  geom_point(data=data2,aes(x =Lat,y =Lon),size=2,pch=21,fill="black")+
  geom_point(data=data3,aes(x =Lat,y =Lon),size=2,pch=21,fill="black")+
  geom_point(data=data4,aes(x =Lat,y =Lon),size=2,pch=21,fill="black")+
  geom_point(data=data5,aes(x =Lat,y =Lon),size=2,pch=21,fill="black")+
  geom_point(data=data6,aes(x =Lat,y =Lon),size=2,pch=21,fill="black")+
  geom_path(data=sde1,aes(x=sde1$x,y=sde1$y,group=1),col="yellow",size=0.5)+
  geom_path(data=sde2,aes(x=sde2$x,y=sde2$y,group=1),col="green",size=0.5)+
  geom_path(data=sde3,aes(x=sde3$x,y=sde3$y,group=1),col="blue",size=0.5)+
  geom_path(data=sde4,aes(x=sde4$x,y=sde4$y,group=1),col="orange",size=0.5)+
  geom_path(data=sde5,aes(x=sde5$x,y=sde5$y,group=1),col="black",size=0.5)+
  geom_path(data=sde6,aes(x=sde6$x,y=sde6$y,group=1),col="purple",size=0.5)
 




